// ============================================================
// SMAI V2 — Frontend Application Logic
// ============================================================

let token = localStorage.getItem('smai_token');
let user  = JSON.parse(localStorage.getItem('smai_user') || '{}');
let isLogin = true;

let agentsCache = [];
let flowsCache = [];
let ivrCache = [];
let dispoCache = [];
let campaignsCache = [];
let flowNodes = [];
let ivrOptions = [];
let selectedMode = 'preview';
let cmDndList = [];

// ── INIT ──────────────────────────────────────────────────────────────────
if (token) { showApp(); loadEverything(); }

// ── AUTH ──────────────────────────────────────────────────────────────────
function toggleAuth() {
  isLogin = !isLogin;
  document.getElementById('auth-box-label').textContent = isLogin ? '— Sign In' : '— Get Started';
  document.getElementById('auth-title').textContent = isLogin ? 'Welcome back' : 'Create your account';
  document.getElementById('auth-switch-text').textContent = isLogin ? "No account yet?" : 'Already registered?';
  document.getElementById('auth-switch-link').textContent = isLogin ? 'Create one' : 'Sign in';
  document.getElementById('auth-submit-btn').textContent = isLogin ? 'Sign In' : 'Create Account';
  document.getElementById('name-field').classList.toggle('hidden', isLogin);
  document.getElementById('company-field').classList.toggle('hidden', isLogin);
  document.getElementById('auth-error').textContent = '';
}

async function handleAuth() {
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-name').value.trim();
  const company = document.getElementById('auth-company').value.trim();
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';

  if (!email || !password) { errEl.textContent = 'Email and password required'; return; }
  if (!isLogin && !name) { errEl.textContent = 'Name is required'; return; }

  const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
  const body = isLogin ? { email, password } : { name, email, password, company };

  try {
    const r = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const d = await r.json();
    if (d.error) { errEl.textContent = d.error; return; }
    token = d.token; user = d.user;
    localStorage.setItem('smai_token', token);
    localStorage.setItem('smai_user', JSON.stringify(user));
    showApp();
    loadEverything();
  } catch (e) {
    errEl.textContent = 'Connection error — check server';
  }
}

function showApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');
  document.getElementById('user-name').textContent = user.name || 'User';
  document.getElementById('user-email').textContent = user.email || '';
  document.getElementById('user-avatar').textContent = (user.name || 'U')[0].toUpperCase();
}

function logout() {
  localStorage.clear();
  token = null; user = {};
  document.getElementById('app-screen').classList.add('hidden');
  document.getElementById('auth-screen').classList.remove('hidden');
}

// ── API HELPER ────────────────────────────────────────────────────────────
async function api(path, method = 'GET', body = null, isForm = false) {
  const headers = { 'Authorization': 'Bearer ' + token };
  if (!isForm) headers['Content-Type'] = 'application/json';
  const opts = { method, headers };
  if (body) opts.body = isForm ? body : JSON.stringify(body);
  const r = await fetch(path, opts);
  return r.json();
}

// ── NAVIGATION ────────────────────────────────────────────────────────────
function showPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.querySelector(`.nav-item[data-page="${page}"]`).classList.add('active');
  const titles = { dashboard:'Dashboard', agents:'AI Agents', flows:'Flow Builder', ivr:'IVR Menus', dispositions:'Dispositions', campaigns:'Campaigns', calls:'Call Logs', dnd:'DND List' };
  document.getElementById('topbar-title').textContent = titles[page];
  document.getElementById('topbar-crumb-page').textContent = titles[page];

  if (page === 'dashboard') loadDashboard();
  if (page === 'agents') loadAgents();
  if (page === 'flows') loadFlows();
  if (page === 'ivr') loadIvrList();
  if (page === 'dispositions') loadDispositions();
  if (page === 'campaigns') loadCampaigns();
  if (page === 'calls') loadCalls();
}

async function loadEverything() {
  await Promise.all([loadAgents(), loadFlows(), loadIvrList(), loadDispositions()]);
  loadDashboard();
  loadCampaigns();
  loadCalls();
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────
async function loadDashboard() {
  const stats = await api('/api/calls/stats');
  document.getElementById('s-total').textContent = stats.total || 0;
  document.getElementById('s-interested').textContent = stats.interested || 0;
  document.getElementById('s-transferred').textContent = stats.transferred || 0;
  document.getElementById('s-duration').textContent = Math.round(stats.avg_duration || 0) + 's';

  const active = campaignsCache.filter(c => c.status === 'active');
  const el = document.getElementById('dash-campaigns-mini');
  if (!active.length) {
    el.innerHTML = '<div class="empty"><div class="ico">&#128226;</div><div class="ttl">No campaigns running</div></div>';
  } else {
    el.innerHTML = active.map(c => `
      <div class="queue-mini">
        <div class="qm-item"><div class="qm-val">${c.name}</div><div class="qm-lbl">Campaign</div></div>
        <div class="qm-item"><div class="qm-val">${(c.queue||[]).length}</div><div class="qm-lbl">In Queue</div></div>
        <div class="qm-item"><div class="qm-val">${c.cps}</div><div class="qm-lbl">CPS</div></div>
        <div class="qm-item"><div class="qm-val">${c.mode}</div><div class="qm-lbl">Mode</div></div>
      </div>
    `).join('');
  }
}

// ── AGENTS ────────────────────────────────────────────────────────────────
async function loadAgents() {
  agentsCache = await api('/api/agents');
  const grid = document.getElementById('agents-grid');
  if (!agentsCache.length) {
    grid.innerHTML = '<div class="empty"><div class="ico">&#9678;</div><div class="ttl">No agents yet</div><div class="sub">Create your first AI agent to get started</div></div>';
    return;
  }
  grid.innerHTML = agentsCache.map(a => `
    <div class="entity-card">
      <div class="entity-card-top">
        <div class="entity-icon">&#9678;</div>
        <span class="badge ${a.status==='active'?'badge-green':'badge-gray'}">${a.status}</span>
      </div>
      <div class="entity-name">${a.name}</div>
      <div class="entity-meta">${a.provider} &middot; ${a.voice} &middot; ${a.language}</div>
      <div class="entity-actions">
        <button class="btn-ghost btn-sm" onclick="deleteAgent('${a.id}')">Delete</button>
      </div>
    </div>
  `).join('');
}

function openAgentModal() {
  document.getElementById('ag-name').value = '';
  document.getElementById('ag-prompt').value = '';
  document.getElementById('agent-modal').classList.remove('hidden');
}

async function createAgent() {
  const name = document.getElementById('ag-name').value.trim();
  const prompt = document.getElementById('ag-prompt').value.trim();
  const voice = document.getElementById('ag-voice').value;
  const language = document.getElementById('ag-language').value;
  const provider = document.getElementById('ag-provider').value;
  if (!name || !prompt) { alert('Name and prompt are required'); return; }
  await api('/api/agents', 'POST', { name, prompt, voice, language, provider });
  closeModal('agent-modal');
  loadAgents();
}

async function deleteAgent(id) {
  if (!confirm('Delete this agent?')) return;
  await api('/api/agents/' + id, 'DELETE');
  loadAgents();
}

// ── FLOWS ─────────────────────────────────────────────────────────────────
async function loadFlows() {
  flowsCache = await api('/api/flows');
  const grid = document.getElementById('flows-grid');
  if (!flowsCache.length) {
    grid.innerHTML = '<div class="empty"><div class="ico">&#8997;</div><div class="ttl">No flows yet</div><div class="sub">Build a flow to define call logic</div></div>';
    return;
  }
  grid.innerHTML = flowsCache.map(f => `
    <div class="entity-card">
      <div class="entity-card-top"><div class="entity-icon">&#8997;</div></div>
      <div class="entity-name">${f.name}</div>
      <div class="entity-meta">${(JSON.parse(f.nodes||'[]')||f.nodes||[]).length || 0} nodes</div>
      <div class="entity-actions">
        <button class="btn-ghost btn-sm" onclick="deleteFlow('${f.id}')">Delete</button>
      </div>
    </div>
  `).join('');
}

function openFlowModal() {
  flowNodes = [];
  document.getElementById('fl-name').value = '';
  renderFlowCanvas();
  document.getElementById('flow-modal').classList.remove('hidden');
}

function addFlowNode(type) {
  flowNodes.push({ id: Date.now(), type, name: type + ' Step' });
  renderFlowCanvas();
}

function removeFlowNode(id) {
  flowNodes = flowNodes.filter(n => n.id !== id);
  renderFlowCanvas();
}

function renderFlowCanvas() {
  const canvas = document.getElementById('flow-canvas');
  if (!flowNodes.length) {
    canvas.innerHTML = '<div style="color:var(--ink-soft);font-size:11.5px;text-align:center;padding:40px">Add nodes below to build your flow</div>';
    return;
  }
  canvas.innerHTML = flowNodes.map(n => `
    <div class="flow-node">
      <span class="fn-del" onclick="removeFlowNode(${n.id})">&times;</span>
      <div class="fn-type">${n.type}</div>
      <div class="fn-name">${n.name}</div>
    </div>
  `).join('');
}

async function createFlow() {
  const name = document.getElementById('fl-name').value.trim();
  if (!name) { alert('Flow name required'); return; }
  await api('/api/flows', 'POST', { name, nodes: flowNodes, edges: [] });
  closeModal('flow-modal');
  loadFlows();
}

async function deleteFlow(id) {
  if (!confirm('Delete this flow?')) return;
  await api('/api/flows/' + id, 'DELETE');
  loadFlows();
}

// ── IVR ───────────────────────────────────────────────────────────────────
async function loadIvrList() {
  ivrCache = await api('/api/ivr');
  const grid = document.getElementById('ivr-grid');
  if (!ivrCache.length) {
    grid.innerHTML = '<div class="empty"><div class="ico">&#9742;</div><div class="ttl">No IVR menus yet</div><div class="sub">Create a menu with keypad options</div></div>';
    return;
  }
  grid.innerHTML = ivrCache.map(i => `
    <div class="entity-card">
      <div class="entity-card-top"><div class="entity-icon">&#9742;</div></div>
      <div class="entity-name">${i.name}</div>
      <div class="entity-meta">${(i.options||[]).length} keypad options</div>
      <div class="entity-actions">
        <button class="btn-ghost btn-sm" onclick="deleteIvr('${i.id}')">Delete</button>
      </div>
    </div>
  `).join('');
}

function openIvrModal() {
  ivrOptions = [];
  document.getElementById('ivr-name').value = '';
  renderIvrOptions();
  document.getElementById('ivr-modal').classList.remove('hidden');
}

function addIvrOption() {
  ivrOptions.push({ id: Date.now(), key: ivrOptions.length + 1, action: 'Transfer to Agent' });
  renderIvrOptions();
}

function removeIvrOption(id) {
  ivrOptions = ivrOptions.filter(o => o.id !== id);
  renderIvrOptions();
}

function renderIvrOptions() {
  const el = document.getElementById('ivr-options-list');
  el.innerHTML = ivrOptions.map(o => `
    <div class="field-row" style="align-items:center;margin-bottom:8px">
      <input type="text" value="${o.key}" style="max-width:60px" onchange="updateIvrKey(${o.id}, this.value)" placeholder="Key"/>
      <div class="inline-flex">
        <input type="text" value="${o.action}" onchange="updateIvrAction(${o.id}, this.value)" placeholder="Action description" style="flex:1"/>
        <button class="btn-ghost btn-sm" onclick="removeIvrOption(${o.id})">&times;</button>
      </div>
    </div>
  `).join('');
}

function updateIvrKey(id, val) { const o = ivrOptions.find(x => x.id === id); if (o) o.key = val; }
function updateIvrAction(id, val) { const o = ivrOptions.find(x => x.id === id); if (o) o.action = val; }

async function createIvr() {
  const name = document.getElementById('ivr-name').value.trim();
  if (!name) { alert('Menu name required'); return; }
  await api('/api/ivr', 'POST', { name, options: ivrOptions });
  closeModal('ivr-modal');
  loadIvrList();
}

async function deleteIvr(id) {
  if (!confirm('Delete this IVR menu?')) return;
  await api('/api/ivr/' + id, 'DELETE');
  loadIvrList();
}

// ── DISPOSITIONS ──────────────────────────────────────────────────────────
async function loadDispositions() {
  dispoCache = await api('/api/dispositions');
  const tbody = document.getElementById('dispo-table');
  if (!dispoCache.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--ink-soft)">No dispositions configured</td></tr>';
    return;
  }
  tbody.innerHTML = dispoCache.map(d => `
    <tr>
      <td><strong>${d.name}</strong></td>
      <td><span style="display:inline-block;width:14px;height:14px;border-radius:3px;background:${d.color}"></span></td>
      <td>${(d.sub_dispositions||[]).join(', ') || '—'}</td>
      <td><button class="btn-ghost btn-sm" onclick="deleteDispo('${d.id}')">Delete</button></td>
    </tr>
  `).join('');
}

function openDispoModal() {
  document.getElementById('dp-name').value = '';
  document.getElementById('dp-subs').value = '';
  document.getElementById('dispo-modal').classList.remove('hidden');
}

async function createDispo() {
  const name = document.getElementById('dp-name').value.trim();
  const color = document.getElementById('dp-color').value;
  const subs = document.getElementById('dp-subs').value.split(',').map(s => s.trim()).filter(Boolean);
  if (!name) { alert('Name required'); return; }
  await api('/api/dispositions', 'POST', { name, color, sub_dispositions: subs });
  closeModal('dispo-modal');
  loadDispositions();
}

async function deleteDispo(id) {
  if (!confirm('Delete this disposition?')) return;
  await api('/api/dispositions/' + id, 'DELETE');
  loadDispositions();
}

// ── CAMPAIGNS ─────────────────────────────────────────────────────────────
async function loadCampaigns() {
  campaignsCache = await api('/api/campaigns');
  const tbody = document.getElementById('campaigns-table');
  if (!campaignsCache.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--ink-soft)">No campaigns yet</td></tr>';
    return;
  }
  tbody.innerHTML = campaignsCache.map(c => `
    <tr>
      <td><strong>${c.name}</strong></td>
      <td><span class="badge badge-blue">${c.mode}</span></td>
      <td>${c.cps}</td>
      <td>${(c.queue||[]).length}</td>
      <td><span class="badge ${c.status==='active'?'badge-green':c.status==='paused'?'badge-orange':'badge-gray'}">${c.status}</span></td>
      <td>
        ${c.status==='draft' ? `<button class="btn-sm btn" onclick="updateCampaignStatus('${c.id}','active')">Launch</button>` : ''}
        ${c.status==='active' ? `<button class="btn-sm btn-outline" onclick="updateCampaignStatus('${c.id}','paused')">Pause</button>` : ''}
        ${c.status==='paused' ? `<button class="btn-sm btn" onclick="updateCampaignStatus('${c.id}','active')">Resume</button>` : ''}
        <button class="btn-ghost btn-sm" onclick="deleteCampaign('${c.id}')">Delete</button>
      </td>
    </tr>
  `).join('');
}

function selectMode(mode) {
  selectedMode = mode;
  document.querySelectorAll('#cm-mode-group .pill').forEach(p => p.classList.toggle('active', p.dataset.mode === mode));
}

function switchTab(tabId) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  event.currentTarget.classList.add('active');
  document.getElementById(tabId).classList.add('active');
}

function addDndToCampaign() {
  const val = document.getElementById('cm-dnd-input').value.trim();
  if (!val) return;
  cmDndList.push(val);
  document.getElementById('cm-dnd-input').value = '';
  renderCmDndChips();
}

function renderCmDndChips() {
  const el = document.getElementById('cm-dnd-chips');
  el.innerHTML = cmDndList.map((n, i) => `
    <div class="chip"><span class="dot" style="background:var(--red)"></span>${n} <span class="x" onclick="removeCmDnd(${i})">&times;</span></div>
  `).join('');
}

function removeCmDnd(i) { cmDndList.splice(i, 1); renderCmDndChips(); }

function openCampaignModal() {
  document.getElementById('cm-name').value = '';
  document.getElementById('cm-cps').value = 1;
  selectedMode = 'preview';
  cmDndList = [];
  document.querySelectorAll('#cm-mode-group .pill').forEach(p => p.classList.toggle('active', p.dataset.mode === 'preview'));
  renderCmDndChips();

  const agentSel = document.getElementById('cm-agent');
  agentSel.innerHTML = agentsCache.length ? agentsCache.map(a => `<option value="${a.id}">${a.name}</option>`).join('') : '<option value="">No agents — create one first</option>';

  const flowSel = document.getElementById('cm-flow');
  flowSel.innerHTML = '<option value="">- None -</option>' + flowsCache.map(f => `<option value="${f.id}">${f.name}</option>`).join('');

  const ivrSel = document.getElementById('cm-ivr');
  ivrSel.innerHTML = '<option value="">- None -</option>' + ivrCache.map(i => `<option value="${i.id}">${i.name}</option>`).join('');

  document.getElementById('campaign-modal').classList.remove('hidden');
}

async function createCampaign() {
  const name = document.getElementById('cm-name').value.trim();
  const cps = parseInt(document.getElementById('cm-cps').value) || 1;
  const status = document.getElementById('cm-status').value;
  const agent_id = document.getElementById('cm-agent').value;
  const flow_id = document.getElementById('cm-flow').value;
  const ivr_id = document.getElementById('cm-ivr').value;
  const schedule_start = document.getElementById('cm-sched-start').value;
  const schedule_end = document.getElementById('cm-sched-end').value;

  if (!name) { alert('Campaign name required'); return; }

  const result = await api('/api/campaigns', 'POST', {
    name, agent_id, flow_id, ivr_id, mode: selectedMode, cps, status, schedule_start, schedule_end
  });

  const fileInput = document.getElementById('cm-leads-file');
  if (fileInput.files.length && result.id) {
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    await api('/api/campaigns/' + result.id + '/leads', 'POST', formData, true);
  }

  for (const phone of cmDndList) {
    if (result.id) await api('/api/campaigns/' + result.id + '/dnd', 'POST', { phone });
  }

  closeModal('campaign-modal');
  loadCampaigns();
  loadDashboard();
}

async function updateCampaignStatus(id, status) {
  await api('/api/campaigns/' + id + '/status', 'PUT', { status });
  loadCampaigns();
  loadDashboard();
}

async function deleteCampaign(id) {
  if (!confirm('Delete this campaign?')) return;
  await api('/api/campaigns/' + id, 'DELETE');
  loadCampaigns();
}

// ── CALLS ─────────────────────────────────────────────────────────────────
async function loadCalls() {
  const calls = await api('/api/calls');
  const tbody = document.getElementById('calls-table');
  if (!calls.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:40px;color:var(--ink-soft)">No calls logged yet</td></tr>';
    return;
  }
  tbody.innerHTML = calls.map(c => `
    <tr>
      <td>${c.phone || '—'}</td>
      <td><span class="badge ${c.outcome==='INTERESTED'?'badge-green':c.outcome==='TRANSFER'?'badge-blue':'badge-gray'}">${c.outcome||'—'}</span></td>
      <td>${c.duration}s</td>
      <td>${new Date(c.created_at).toLocaleString()}</td>
    </tr>
  `).join('');
}

// ── MODAL HELPERS ─────────────────────────────────────────────────────────
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

// Refresh dashboard periodically
setInterval(() => { if (!document.getElementById('app-screen').classList.contains('hidden')) loadDashboard(); }, 20000);
