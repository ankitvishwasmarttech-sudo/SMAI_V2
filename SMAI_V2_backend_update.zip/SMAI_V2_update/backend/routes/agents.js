const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/schema');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', auth, (req, res) => res.json(db.prepare('SELECT * FROM agents WHERE user_id=? ORDER BY created_at DESC').all(req.user.id)));

router.post('/', auth, (req, res) => {
  const { name, prompt, voice, language, provider } = req.body;
  if (!name || !prompt) return res.status(400).json({ error: 'Name and prompt required' });
  const id = uuidv4();
  db.prepare('INSERT INTO agents (id,user_id,name,prompt,voice,language,provider) VALUES (?,?,?,?,?,?,?)')
    .run(id,req.user.id,name,prompt,voice||'alloy',language||'hinglish',provider||'groq');
  res.json({ id, name, prompt, voice, language, provider, status: 'active' });
});

router.put('/:id', auth, (req, res) => {
  const { name, prompt, voice, language, provider, status } = req.body;
  db.prepare('UPDATE agents SET name=?,prompt=?,voice=?,language=?,provider=?,status=? WHERE id=? AND user_id=?')
    .run(name,prompt,voice,language,provider,status,req.params.id,req.user.id);
  res.json({ success: true });
});

router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM agents WHERE id=? AND user_id=?').run(req.params.id,req.user.id);
  res.json({ success: true });
});

// List of supported providers with metadata — used by frontend to render options
router.get('/providers/list', auth, (req, res) => {
  res.json([
    { id: 'openai',    name: 'OpenAI Realtime',  type: 'native_ws', voices: ['alloy','echo','fable','onyx','nova','shimmer'] },
    { id: 'gemini',    name: 'Gemini Live',       type: 'native_ws', voices: ['Puck','Charon','Kore','Fenrir'] },
    { id: 'groq',      name: 'Groq (LLaMA3)',     type: 'pipeline',  voices: ['default'] },
    { id: 'claude',    name: 'Claude (Anthropic)', type: 'pipeline', voices: ['default'] },
    { id: 'nvidia',    name: 'NVIDIA NIM',        type: 'pipeline',  voices: ['default'] },
    { id: 'azure',     name: 'Azure OpenAI',      type: 'native_ws', voices: ['alloy','echo','nova'] },
    { id: 'elevenlabs',name: 'ElevenLabs (TTS)',  type: 'tts_only',  voices: ['Rachel','Adam','Bella','Domi'] },
    { id: 'deepgram',  name: 'Deepgram (STT)',    type: 'stt_only',  voices: ['default'] },
    { id: 'deepseek',  name: 'DeepSeek',          type: 'pipeline',  voices: ['default'] },
    { id: 'grok',      name: 'Grok (xAI)',        type: 'pipeline',  voices: ['default'] },
  ]);
});

module.exports = router;
