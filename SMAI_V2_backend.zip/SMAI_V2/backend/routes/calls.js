
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/schema');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM calls WHERE user_id=? ORDER BY created_at DESC LIMIT 200').all(req.user.id));
});

router.get('/stats', auth, (req, res) => {
  res.json(db.prepare(`SELECT
    COUNT(*) as total,
    SUM(CASE WHEN outcome='INTERESTED' THEN 1 ELSE 0 END) as interested,
    SUM(CASE WHEN outcome='TRANSFER' THEN 1 ELSE 0 END) as transferred,
    SUM(CASE WHEN outcome='NOT_INTERESTED' THEN 1 ELSE 0 END) as not_interested,
    AVG(duration) as avg_duration
    FROM calls WHERE user_id=?`).get(req.user.id));
});

router.post('/webhook', (req, res) => {
  const { uuid, outcome, user_id, campaign_id, agent_id, duration, transcript, phone } = req.body;
  db.prepare('INSERT OR REPLACE INTO calls (id,user_id,campaign_id,agent_id,phone,duration,outcome,transcript) VALUES (?,?,?,?,?,?,?,?)').run(uuid||uuidv4(),user_id||'system',campaign_id||null,agent_id||null,phone||'',duration||0,outcome,transcript||'');
  res.json({ success: true });
});

module.exports = router;
