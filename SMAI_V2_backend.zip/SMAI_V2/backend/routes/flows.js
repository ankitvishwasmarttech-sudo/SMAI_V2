
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/schema');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', auth, (req, res) => res.json(db.prepare('SELECT * FROM flows WHERE user_id=? ORDER BY created_at DESC').all(req.user.id)));
router.post('/', auth, (req, res) => {
  const { name, nodes, edges } = req.body;
  const id = uuidv4();
  db.prepare('INSERT INTO flows (id,user_id,name,nodes,edges) VALUES (?,?,?,?,?)').run(id,req.user.id,name,JSON.stringify(nodes||[]),JSON.stringify(edges||[]));
  res.json({ id, name, nodes: nodes||[], edges: edges||[] });
});
router.put('/:id', auth, (req, res) => {
  const { name, nodes, edges } = req.body;
  db.prepare('UPDATE flows SET name=?,nodes=?,edges=? WHERE id=? AND user_id=?').run(name,JSON.stringify(nodes||[]),JSON.stringify(edges||[]),req.params.id,req.user.id);
  res.json({ success: true });
});
router.delete('/:id', auth, (req, res) => {
  db.prepare('DELETE FROM flows WHERE id=? AND user_id=?').run(req.params.id,req.user.id);
  res.json({ success: true });
});
module.exports = router;
